// Oyun durumu
export const gameState = {
    questions: [],
    currentQuestionIndex: 0,
    score: 0,
    correctAnswers: 0,
    wrongAnswers: 0,
    timeLeft: 45,
    timer: null,
    selectedCategory: '',
    selectedLevel: '',
    soundEnabled: true
};

// Oyun durumunu sıfırla
export function resetGameState() {
    gameState.currentQuestionIndex = 0;
    gameState.score = 0;
    gameState.correctAnswers = 0;
    gameState.wrongAnswers = 0;
    gameState.timeLeft = 45;
    if (gameState.timer) {
        clearInterval(gameState.timer);
        gameState.timer = null;
    }
}
