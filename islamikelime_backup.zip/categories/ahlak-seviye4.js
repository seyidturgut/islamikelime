const ahlak4Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da alçakgönüllülük hangi kavramla ifade edilir?",
    options: ["Tevazu", "Tevekkül", "Takva", "Teslimiyet"],
    correctAnswer: "Tevazu",
    explanation: "Tevazu, İslam ahlakında alçakgönüllülük ve kibir sahibi olmamayı ifade eden önemli bir kavramdır.",
    difficulty: 4
  }
];

window.ahlak4Questions = ahlak4Questions;
