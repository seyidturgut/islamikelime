const ahlak9Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da 'Edep' kavramı neyi ifade eder?",
    options: ["Görgü kurallarına uymak", "Sadece ibadet etmek", "Yalnızca namaz kılmak", "Sadece oruç tutmak"],
    correctAnswer: "Görgü kurallarına uymak",
    explanation: "Edep, İslam'da görgü kurallarına uymak, uygun davranışlar sergilemek ve ahlaki değerlere bağlı kalmak anlamına gelir.",
    difficulty: 9
  }
];

window.ahlak9Questions = ahlak9Questions;
