const ahlak7Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da komşu hakkı kaç eve kadardır?",
    options: ["40", "30", "20", "10"],
    correctAnswer: "40",
    explanation: "İslam'da komşu hakkı 40 ev mesafesine kadar olan komşuları kapsar ve onlara karşı sorumluluklarımız vardır.",
    difficulty: 7
  }
];

window.ahlak7Questions = ahlak7Questions;
