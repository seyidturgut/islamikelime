const ahlak2Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da doğruluk ve dürüstlük hangi kavramla ifade edilir?",
    options: ["Sıdk", "Emanet", "Adalet", "Merhamet"],
    correctAnswer: "Sıdk",
    explanation: "Sıdk, İslam ahlakında doğruluk ve dürüstlüğü ifade eden temel kavramdır.",
    difficulty: 2
  }
];

window.ahlak2Questions = ahlak2Questions;
