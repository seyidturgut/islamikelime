const ahlak3Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da güvenilirlik ve emaneti koruma hangi kavramla ifade edilir?",
    options: ["Emanet", "Sıdk", "Adalet", "Merhamet"],
    correctAnswer: "Emanet",
    explanation: "Emanet, İslam ahlakında güvenilirlik ve kendisine verilen şeyi korumayı ifade eden temel kavramdır.",
    difficulty: 3
  }
];

window.ahlak3Questions = ahlak3Questions;
