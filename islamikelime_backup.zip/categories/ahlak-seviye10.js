const ahlak10Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da 'Hilm' kavramı neyi ifade eder?",
    options: ["Yumuşak huyluluk", "Sertlik", "Öfke", "Acelecilik"],
    correctAnswer: "Yumuşak huyluluk",
    explanation: "Hilm, İslam ahlakında yumuşak huyluluk, ağırbaşlılık ve olgunluk anlamına gelen önemli bir kavramdır.",
    difficulty: 10
  }
];

window.ahlak10Questions = ahlak10Questions;
