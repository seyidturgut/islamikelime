const ahlak8Questions = [
  {
    turkish: "Ahlak",
    question: "İslam'da 'Hüsn-ü zan' ne demektir?",
    options: ["İyi niyet beslemek", "Kötü düşünmek", "Tarafsız kalmak", "Şüphe duymak"],
    correctAnswer: "İyi niyet beslemek",
    explanation: "Hüsn-ü zan, başkaları hakkında iyi niyet beslemek ve olumlu düşünmek anlamına gelir.",
    difficulty: 8
  }
];

window.ahlak8Questions = ahlak8Questions;
